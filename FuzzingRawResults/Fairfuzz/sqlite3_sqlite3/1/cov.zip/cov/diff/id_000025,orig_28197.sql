diff id:000024,orig:27639.sql -> id:000025,orig:28197.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 151739
  New 'line' coverage: 151745
  New 'line' coverage: 151747
  New 'line' coverage: 151759
  New 'line' coverage: 151763
  New 'line' coverage: 151765
  New 'line' coverage: 30151
  New 'line' coverage: 30152
