diff id:000008,orig:1554.sql -> id:000009,orig:16422.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 140052
  New 'line' coverage: 140053
  New 'line' coverage: 96514
  New 'line' coverage: 99438
  New 'line' coverage: 99439
