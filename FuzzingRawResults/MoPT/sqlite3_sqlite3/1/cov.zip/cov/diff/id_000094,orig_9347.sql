diff id:000093,orig:9046.sql -> id:000094,orig:9347.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 151707
  New 'line' coverage: 151719
  New 'line' coverage: 155439
  New 'line' coverage: 155440
  New 'line' coverage: 31169
