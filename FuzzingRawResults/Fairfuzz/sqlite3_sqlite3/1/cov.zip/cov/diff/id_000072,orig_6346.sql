diff id:000071,orig:6039.sql -> id:000072,orig:6346.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 108798
  New 'line' coverage: 137668
  New 'line' coverage: 76186
  New 'line' coverage: 76193
  New 'line' coverage: 89679
