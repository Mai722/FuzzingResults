diff id:000057,orig:4094.sql -> id:000058,orig:4102.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 155271
  New 'line' coverage: 155272
  New 'line' coverage: 155273
  New 'line' coverage: 156025
  New 'line' coverage: 156026
  New 'line' coverage: 28037
  New 'line' coverage: 28038
  New 'line' coverage: 28041
  New 'line' coverage: 28043
  New 'line' coverage: 28044
  New 'line' coverage: 28045
  New 'line' coverage: 28047
  New 'line' coverage: 28048
  New 'line' coverage: 74926
