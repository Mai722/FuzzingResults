diff id:000068,orig:5700.sql -> id:000069,orig:5804.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 153182
  New 'line' coverage: 153183
