diff id:000083,orig:8044.sql -> id:000084,orig:8086.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 111926
  New 'line' coverage: 111927
  New 'line' coverage: 111931
  New 'line' coverage: 111932
  New 'line' coverage: 125767
  New 'line' coverage: 153841
  New 'line' coverage: 153843
  New 'line' coverage: 153844
  New 'line' coverage: 153845
  New 'line' coverage: 153846
  New 'line' coverage: 153847
  New 'line' coverage: 153848
