diff id:000094,orig:9347.sql -> id:000095,orig:9485.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 125885
  New 'line' coverage: 125974
  New 'line' coverage: 125977
  New 'line' coverage: 96720
