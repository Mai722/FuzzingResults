diff id:000070,orig:598.sql -> id:000071,orig:6039.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 72719
  New 'line' coverage: 72720
  New 'line' coverage: 72721
  New 'line' coverage: 72758
