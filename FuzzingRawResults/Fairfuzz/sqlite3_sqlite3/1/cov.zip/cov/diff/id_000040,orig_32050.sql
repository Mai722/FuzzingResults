diff id:000039,orig:31858.sql -> id:000040,orig:32050.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 115112
  New 'line' coverage: 115113
  New 'line' coverage: 115114
  New 'line' coverage: 115305
  New 'line' coverage: 115306
  New 'line' coverage: 115307
  New 'line' coverage: 115309
