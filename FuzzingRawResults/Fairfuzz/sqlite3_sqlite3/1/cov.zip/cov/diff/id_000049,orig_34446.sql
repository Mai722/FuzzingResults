diff id:000048,orig:34423.sql -> id:000049,orig:34446.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 140503
