diff id:000031,orig:30334.sql -> id:000032,orig:30354.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 130087
  New 'line' coverage: 131166
  New 'line' coverage: 131629
  New 'line' coverage: 131631
