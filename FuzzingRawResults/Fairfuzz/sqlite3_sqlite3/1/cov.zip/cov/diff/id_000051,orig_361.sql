diff id:000050,orig:35351.sql -> id:000051,orig:361.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 122974
  New 'line' coverage: 122976
  New 'line' coverage: 122977
  New 'line' coverage: 122978
  New 'line' coverage: 122981
  New 'line' coverage: 122982
  New 'line' coverage: 122985
  New 'line' coverage: 122988
  New 'line' coverage: 122990
  New 'line' coverage: 54442
