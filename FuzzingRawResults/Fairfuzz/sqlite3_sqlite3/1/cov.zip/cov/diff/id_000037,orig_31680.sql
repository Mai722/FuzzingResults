diff id:000036,orig:31433.sql -> id:000037,orig:31680.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 129377
  New 'line' coverage: 129378
  New 'line' coverage: 129381
  New 'line' coverage: 129384
  New 'line' coverage: 129385
  New 'line' coverage: 129386
  New 'line' coverage: 129389
  New 'line' coverage: 155300
  New 'line' coverage: 155301
  New 'line' coverage: 85560
  New 'line' coverage: 85561
  New 'line' coverage: 85562
  New 'line' coverage: 85563
  New 'line' coverage: 85564
