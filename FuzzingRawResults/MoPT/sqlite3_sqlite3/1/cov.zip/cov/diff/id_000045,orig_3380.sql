diff id:000044,orig:33544.sql -> id:000045,orig:3380.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 118407
  New 'line' coverage: 118408
  New 'line' coverage: 118754
  New 'line' coverage: 85191
  New 'line' coverage: 85193
  New 'line' coverage: 85194
  New 'line' coverage: 85195
