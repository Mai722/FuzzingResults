diff id:000077,orig:7007.sql -> id:000078,orig:7207.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 98312
