diff id:000074,orig:6377.sql -> id:000075,orig:6769.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 101159
  New 'line' coverage: 101160
  New 'line' coverage: 75432
  New 'line' coverage: 75433
  New 'line' coverage: 75434
