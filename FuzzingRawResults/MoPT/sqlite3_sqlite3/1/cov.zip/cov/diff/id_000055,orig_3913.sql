diff id:000054,orig:39.sql -> id:000055,orig:3913.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 153937
  New 'line' coverage: 153938
  New 'line' coverage: 159063
  New 'line' coverage: 65819
  New 'line' coverage: 65959
  New 'line' coverage: 65960
  New 'line' coverage: 65965
  New 'line' coverage: 65968
  New 'line' coverage: 65969
  New 'line' coverage: 65970
  New 'line' coverage: 65973
  New 'line' coverage: 66035
  New 'line' coverage: 66038
  New 'line' coverage: 66039
  New 'line' coverage: 77933
  New 'line' coverage: 77934
