diff id:000072,orig:6346.sql -> id:000073,orig:635.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'function' coverage: sqlite3NotPureFunc()
  New 'line' coverage: 153061
  New 'line' coverage: 153062
  New 'line' coverage: 21466
  New 'line' coverage: 21467
  New 'line' coverage: 81483
  New 'line' coverage: 81487
