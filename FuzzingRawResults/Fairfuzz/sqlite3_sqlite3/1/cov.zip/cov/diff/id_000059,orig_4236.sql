diff id:000058,orig:4102.sql -> id:000059,orig:4236.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'function' coverage: compileoptionusedFunc()
  New 'line' coverage: 114910
  New 'line' coverage: 114922
  New 'line' coverage: 114925
  New 'line' coverage: 85954
  New 'line' coverage: 85955
  New 'line' coverage: 85957
