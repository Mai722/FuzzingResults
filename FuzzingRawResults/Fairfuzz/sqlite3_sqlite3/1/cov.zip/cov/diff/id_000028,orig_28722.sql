diff id:000027,orig:28579.sql -> id:000028,orig:28722.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 140202
  New 'line' coverage: 140204
  New 'line' coverage: 140212
  New 'line' coverage: 140213
  New 'line' coverage: 140214
  New 'line' coverage: 140215
  New 'line' coverage: 140216
  New 'line' coverage: 140217
  New 'line' coverage: 140218
  New 'line' coverage: 143792
  New 'line' coverage: 143793
  New 'line' coverage: 143806
  New 'line' coverage: 143808
  New 'line' coverage: 143810
  New 'line' coverage: 143845
  New 'line' coverage: 31864
