diff id:000092,orig:8998.sql -> id:000093,orig:9046.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 87331
  New 'line' coverage: 87332
  New 'line' coverage: 87336
  New 'line' coverage: 87337
