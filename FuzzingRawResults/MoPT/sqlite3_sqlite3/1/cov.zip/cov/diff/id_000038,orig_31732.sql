diff id:000037,orig:31680.sql -> id:000038,orig:31732.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 96459
  New 'line' coverage: 96460
  New 'line' coverage: 96463
  New 'line' coverage: 96578
  New 'line' coverage: 96580
