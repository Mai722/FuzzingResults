diff id:000035,orig:30861.sql -> id:000036,orig:31433.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 127681
  New 'line' coverage: 127682
  New 'line' coverage: 127683
  New 'line' coverage: 127684
  New 'line' coverage: 127685
  New 'line' coverage: 127686
  New 'line' coverage: 127692
  New 'line' coverage: 141872
  New 'line' coverage: 141873
  New 'line' coverage: 141874
  New 'line' coverage: 141875
  New 'line' coverage: 153681
  New 'line' coverage: 153683
  New 'line' coverage: 153685
