diff id:000049,orig:34446.sql -> id:000050,orig:35351.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 103010
