diff id:000095,orig:9485.sql -> id:000096,orig:9631.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 27954
  New 'line' coverage: 27955
  New 'line' coverage: 27956
  New 'line' coverage: 27957
  New 'line' coverage: 76213
  New 'line' coverage: 78101
  New 'line' coverage: 78102
  New 'line' coverage: 78103
  New 'line' coverage: 78105
  New 'line' coverage: 78107
  New 'line' coverage: 78108
