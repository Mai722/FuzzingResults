diff id:000084,orig:8086.sql -> id:000085,orig:8104.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'function' coverage: binaryToUnaryIfNull.isra.189()
  New 'line' coverage: 149815
  New 'line' coverage: 149816
  New 'line' coverage: 149817
  New 'line' coverage: 149822
  New 'line' coverage: 153764
  New 'line' coverage: 153766
  New 'line' coverage: 153767
  New 'line' coverage: 153770
  New 'line' coverage: 153772
  New 'line' coverage: 153773
  New 'line' coverage: 96673
  New 'line' coverage: 96675
  New 'line' coverage: 96679
