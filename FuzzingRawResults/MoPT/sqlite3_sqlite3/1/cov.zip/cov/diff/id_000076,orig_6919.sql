diff id:000075,orig:6769.sql -> id:000076,orig:6919.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 155445
  New 'line' coverage: 155446
  New 'line' coverage: 155447
  New 'line' coverage: 156030
  New 'line' coverage: 156031
  New 'line' coverage: 156032
  New 'line' coverage: 156033
  New 'line' coverage: 80731
  New 'line' coverage: 85582
  New 'line' coverage: 85705
