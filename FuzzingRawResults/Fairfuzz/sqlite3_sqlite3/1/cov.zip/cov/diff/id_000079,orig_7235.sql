diff id:000078,orig:7207.sql -> id:000079,orig:7235.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 122688
  New 'line' coverage: 122689
  New 'line' coverage: 122690
  New 'line' coverage: 122692
  New 'line' coverage: 122699
  New 'line' coverage: 122705
  New 'line' coverage: 122706
  New 'line' coverage: 122707
