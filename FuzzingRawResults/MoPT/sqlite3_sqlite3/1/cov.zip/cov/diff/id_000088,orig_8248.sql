diff id:000087,orig:8242.sql -> id:000088,orig:8248.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 27810
  New 'line' coverage: 30869
  New 'line' coverage: 30921
  New 'line' coverage: 30931
  New 'line' coverage: 30935
  New 'line' coverage: 85585
  New 'line' coverage: 85587
  New 'line' coverage: 85588
  New 'line' coverage: 85589
