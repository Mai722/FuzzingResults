diff id:000053,orig:3795.sql -> id:000054,orig:39.sql
Src file: /MOpt-AFL/MOpt/code1/sqlite3.c
  New 'line' coverage: 100732
  New 'line' coverage: 100734
  New 'line' coverage: 140743
  New 'line' coverage: 99781
  New 'line' coverage: 99949
