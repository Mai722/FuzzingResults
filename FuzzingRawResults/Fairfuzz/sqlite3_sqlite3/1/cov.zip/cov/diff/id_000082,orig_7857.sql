diff id:000081,orig:7815.sql -> id:000082,orig:7857.sql
Src file: /afl-rb/code1/sqlite3.c
  New 'line' coverage: 111906
  New 'line' coverage: 111910
  New 'line' coverage: 111915
  New 'line' coverage: 111916
  New 'line' coverage: 130113
  New 'line' coverage: 130114
  New 'line' coverage: 130116
  New 'line' coverage: 130117
  New 'line' coverage: 130120
  New 'line' coverage: 130125
  New 'line' coverage: 153478
  New 'line' coverage: 153479
